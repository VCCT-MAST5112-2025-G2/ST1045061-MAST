// App.tsx
// Chef Christoffel - Part 2 (MAST5112 POE)
// React Native (Expo) + TypeScript single-file app
// Instructions:
// 1. Create a new Expo TypeScript app: `npx create-expo-app -t expo-template-blank-typescript ChefChristoffelApp`
// 2. Replace the generated App.tsx with this file.
// 3. Run: `cd ChefChristoffelApp && npx expo start`
// No extra packages required.

import React, { useState, useRef } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Keyboard,
  Alert,
  Animated,
  Easing,
  Platform,
} from 'react-native';

type Course = 'Starter' | 'Main' | 'Dessert';

type Dish = {
  id: string;
  name: string;
  description: string;
  course: Course;
  price: number;
};

export default function App() {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState<Course>('Main');
  const [priceText, setPriceText] = useState('');
  const [menu, setMenu] = useState<Dish[]>([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  // animation value used for newly added item
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const addDish = () => {
    // basic validation using if-statements
    if (name.trim().length === 0) {
      Alert.alert('Validation', 'Please enter a dish name.');
      return;
    }
    if (description.trim().length === 0) {
      Alert.alert('Validation', 'Please enter a description.');
      return;
    }
    const price = parseFloat(priceText);
    if (isNaN(price) || price <= 0) {
      Alert.alert('Validation', 'Please enter a valid price greater than 0.');
      return;
    }

    const newDish: Dish = {
      id: String(Date.now()),
      name: name.trim(),
      description: description.trim(),
      course,
      price: Math.round(price * 100) / 100,
    };

    // add new dish to front of array
    setMenu((prev) => [newDish, ...prev]);

    // clear inputs
    setName('');
    setDescription('');
    setPriceText('');
    setCourse('Main');
    setDropdownOpen(false);
    Keyboard.dismiss();

    // run simple animation
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      easing: Easing.out(Easing.ease),
      useNativeDriver: true,
    }).start();
  };

  const removeDish = (id: string) => {
    Alert.alert('Remove Dish', 'Are you sure you want to remove this dish?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => setMenu((prev) => prev.filter((d) => d.id !== id)),
      },
    ]);
  };

  const renderDish = ({ item }: { item: Dish }) => {
    return (
      <Animated.View style={[styles.dishCard, { opacity: fadeAnim }]}> 
        <View style={styles.dishHeader}>
          <Text style={styles.dishName}>{item.name}</Text>
          <Text style={styles.dishPrice}>R {item.price.toFixed(2)}</Text>
        </View>
        <Text style={styles.dishCourse}>{item.course}</Text>
        <Text style={styles.dishDesc}>{item.description}</Text>
        <View style={styles.dishActions}>
          <TouchableOpacity onPress={() => removeDish(item.id)} style={styles.removeBtn}>
            <Text style={styles.removeBtnText}>Remove</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Chef Christoffel — Menu Builder</Text>
      <View style={styles.row}>
        <View style={styles.form}>
          <Text style={styles.label}>Dish name</Text>
          <TextInput
            placeholder="e.g. Springbok Carpaccio"
            value={name}
            onChangeText={setName}
            style={styles.input}
            returnKeyType="next"
          />

          <Text style={styles.label}>Description</Text>
          <TextInput
            placeholder="Short description"
            value={description}
            onChangeText={setDescription}
            style={[styles.input, styles.textArea]}
            multiline
            numberOfLines={3}
          />

          <Text style={styles.label}>Course</Text>
          <TouchableOpacity
            style={styles.dropdown}
            onPress={() => setDropdownOpen((s) => !s)}
            accessibilityRole="button"
          >
            <Text style={styles.dropdownText}>{course} ▾</Text>
          </TouchableOpacity>
          {dropdownOpen && (
            <View style={styles.dropdownList}>
              {(['Starter', 'Main', 'Dessert'] as Course[]).map((c) => (
                <TouchableOpacity
                  key={c}
                  onPress={() => {
                    setCourse(c);
                    setDropdownOpen(false);
                  }}
                  style={styles.dropdownItem}
                >
                  <Text style={styles.dropdownItemText}>{c}</Text>
                </TouchableOpacity>
              ))}
            </View>
          )}

          <Text style={styles.label}>Price (R)</Text>
          <TextInput
            placeholder="e.g. 125.50"
            keyboardType={Platform.OS === 'web' ? 'numeric' : 'decimal-pad'}
            value={priceText}
            onChangeText={setPriceText}
            style={styles.input}
          />

          <TouchableOpacity style={styles.addBtn} onPress={addDish}>
            <Text style={styles.addBtnText}>Add Dish</Text>
          </TouchableOpacity>

          <Text style={styles.hint}>Tip: Use the Remove button on items to delete them.</Text>
        </View>

        <View style={styles.menuPanel}>
          <View style={styles.menuHeader}>
            <Text style={styles.menuTitle}>Menu</Text>
            <Text style={styles.counter}>{menu.length} item{menu.length === 1 ? '' : 's'}</Text>
          </View>

          <FlatList
            data={menu}
            keyExtractor={(i) => i.id}
            renderItem={renderDish}
            ListEmptyComponent={<Text style={styles.empty}>No dishes yet. Add some!</Text>}
            contentContainerStyle={{ paddingBottom: 40 }}
          />
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>Data is in-memory only — it will reset on reload.</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff8f1',
    paddingHorizontal: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    textAlign: 'center',
    marginVertical: 12,
  },
  row: {
    flex: 1,
    flexDirection: 'row',
    gap: 12,
  },
  form: {
    flex: 1,
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    elevation: 2,
  },
  label: {
    fontSize: 14,
    marginTop: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 8,
    marginTop: 6,
  },
  textArea: {
    minHeight: 60,
    textAlignVertical: 'top',
  },
  dropdown: {
    marginTop: 6,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 10,
  },
  dropdownText: { fontSize: 16 },
  dropdownList: {
    marginTop: 6,
    backgroundColor: '#fff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e0e0e0',
    overflow: 'hidden',
  },
  dropdownItem: { padding: 10 },
  dropdownItemText: {},
  addBtn: {
    marginTop: 12,
    backgroundColor: '#c0392b',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  addBtnText: { color: 'white', fontWeight: '700' },
  hint: { marginTop: 8, fontSize: 12, color: '#666' },

  menuPanel: {
    width: 420,
    maxWidth: '48%',
    marginLeft: 12,
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 12,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    elevation: 2,
  },
  menuHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  menuTitle: { fontSize: 20, fontWeight: '700' },
  counter: { color: '#555' },
  empty: { marginTop: 20, color: '#666' },

  dishCard: {
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#eee',
    marginTop: 10,
    backgroundColor: '#fff',
  },
  dishHeader: { flexDirection: 'row', justifyContent: 'space-between' },
  dishName: { fontWeight: '700', fontSize: 16 },
  dishPrice: { fontWeight: '700' },
  dishCourse: { marginTop: 6, fontStyle: 'italic', color: '#333' },
  dishDesc: { marginTop: 6, color: '#444' },
  dishActions: { marginTop: 10, flexDirection: 'row', justifyContent: 'flex-end' },
  removeBtn: { paddingHorizontal: 8, paddingVertical: 6 },
  removeBtnText: { color: '#c0392b', fontWeight: '700' },

  footer: { padding: 8, alignItems: 'center' },
  footerText: { color: '#555', fontSize: 12 },
});

